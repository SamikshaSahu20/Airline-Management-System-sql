<?php
// Establish a database connection
$servername = "localhost";
$username = "root";
$password = ""; // Your database password
$database = "flight"; // Replace 'your_database_name' with your actual database name
$con = mysqli_connect($servername, $username, $password, $database);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are filled
    if(isset($_POST['card_number']) && isset($_POST['expiry']) && isset($_POST['cvc']) && isset($_POST['amount']) && isset($_POST['optradio'])) {
        // Sanitize form data
        $card_number = mysqli_real_escape_string($con, $_POST['card_number']);
        $expiry = mysqli_real_escape_string($con, $_POST['expiry']);
        $cvc = mysqli_real_escape_string($con, $_POST['cvc']);
        $amount = mysqli_real_escape_string($con, $_POST['amount']);
        
        // Determine card type based on the selected radio button
        $card_type = '';
        if($_POST['optradio'] == 'mastercard') {
            $card_type = 'Mastercard';
        } elseif($_POST['optradio'] == 'visa') {
            $card_type = 'Visa';
        }

        // Insert payment information into the database
        $insert_sql = "INSERT INTO payments (card_number, expiry, cvc, amount, card_type) VALUES ('$card_number', '$expiry', '$cvc', '$amount', '$card_type')";
        if (mysqli_query($con, $insert_sql)) {
            echo "Payment information stored successfully.";
        } else {
            echo "Error storing payment information: " . mysqli_error($con);
        }
    } else {
        echo "All fields are required.";
    }
}

// Close the database connection
mysqli_close($con);
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Payment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Poppins">
    <link rel="stylesheet" href="mycss.css">
    <style type="text/css">
        label {
            color: white;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse" style="border-radius:0px !important; margin:0;border: 0">
        <div class="container-fluid">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>                       
              </button>
              <a class="navbar-brand" href="index.html">Airline-X</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="index.html">Home</a></li>
                    <li class="active"><a href="booking.html">Booking</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="contactus.html">Contact Us</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                </ul>
                <form class="navbar-form navbar-right">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search">
                    <div class="input-group-btn">
                      <button class="btn btn-default" type="submit">
                        <i class="glyphicon glyphicon-search"></i>
                      </button>
                    </div>
                  </div>
                </form>
            </div>  
        </div>
    </nav>
    <div class="background-wrapper" style="background-image: url(images/airline/cc.jpg);">
        <div class="container-fluid">
            <header>
                <h2>Payment</h2>
                <hr>
            </header>
            <div class="col-sm-6 col-sm-offset-3">
                <div class="panel-group">
                    <div class="panel panel-default panel-transparent">
                        <div class="panel-heading">
                            <legend style="text-align: center;">Payment Information</legend>
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal" action="" method="post" style="padding: 0 5rem 0 5rem; width: 100%">
                                <div class="form-group">
                                    <label class="radio-inline">
                                          <input type="radio" name="optradio" value="mastercard" style="height: 5rem">
                                          <img src="https://tse1.mm.bing.net/th?id=OIP.IFATrV6ZrvBdbKIBqaw6MQHaEl&pid=Api&rs=1&c=1&qlt=95&w=194&h=120">
                                    </label>
                                    <label class="radio-inline">
                                          <input type="radio" name="optradio" value="visa" style="height: 5rem">
                                          <img src="https://tse3.mm.bing.net/th?id=OIP.qwQzKh7iBDrTEN8RWNM6pQHaEx&pid=Api&P=0&h=180">
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label for="name">Card Number</label>
                                    <input type="text" class="form-control trans-input-area" placeholder="Card Number" name="card_number" required>
                                </div>
                                <div class="form-group">
                                    <div style="float: left; width: 46%">
                                        <label for="Country">Expiry</label>
                                        <input type="text" class="form-control trans-input-area" placeholder="MM/YY" name="expiry" id="" required>
                                    </div>
                                    <div style="float: right; width: 46%">
                                        <label for="Country">CVC</label>
                                        <input type="number" class="form-control trans-input-area" placeholder="CVC" name="cvc" id="" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for ="amount">Amount to Pay</label>
                                    <input type="number" class="form-control trans-input-area" placeholder="Enter amount" name="amount" required>
                                </div>
                                <br>
                                <div>
                                    <button class="btn btn-primary btn-block trans-input-area" type="submit">Click to Pay</button>
                                </div>
                            </form>
                            <br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer -->
        <footer id="footer">
            <div class="container-fluid">
                <ul class="icons">
                    <li><a href="#" class="fa fa-twitter" style="color: grey"></a></li>
                    <li><a href="#" class="fa fa-facebook" style="color: grey"></a></li>
                    <li><a href="#" class="fa fa-instagram" style="color: grey"></a></li>
                    <li><a href="#" class="fa fa-envelope" style="color: grey"></a></li>
                </ul>
            </div>
            <div class="copyright">
                &copy; Airline-X. All rights reserved.
            </div>
        </footer>
    </div>
</body>
<style>
    .small-image {
        width: 50px; /* Adjust the width as needed */
        height: auto; /* Maintain the aspect ratio */
    }
</style>
</html>

